#!/bin/bash

# commands for benchmarking starfish against a database of 42 manually annotated elements

conda activate starfish

cd benchmarking/
mkdir geneFinder/
mkdir elementFinder/

starfish annotate -x 42inserts -i tyr -p YRsuperfams.p1-512.hmm -P YRsuperfamRefs.faa -o geneFinder/ -T 8 -a 84contigpath.txt

starfish sketch -q 42inserts.filt.ids -m 10000 -g filtGFFpath.txt -i s -x 42inserts -o ./

makeblastdb -dbtype nucl -parse_seqids -in 84contigs.fna -out 84contigs

starfish insert -T 8 --upstream 0-17000 --downstream 0-14000 --length 2000-700000 --pid 90 -a 84contigpath.txt -d data/84contigs -b geneFinder/42inserts.bed -i tyr -x benchmarks1 -o elementFinder/

starfish insert -T 8 --upstream 0-8500 --downstream 0-7000 --length 2000-700000 --pid 90 -a 84contigpath.txt -d data/84contigs -b elementFinder/benchmarks1.insert.bed -i tyr -x benchmarks2 -o elementFinder/

starfish insert -T 8 --upstream 0-8500 --downstream 0-7000 --length 2000-700000 --pid 80 -a 84contigpath.txt -d data/84contigs -b elementFinder/benchmarks2.insert.bed -i tyr -x benchmarks3 -o elementFinder/

starfish flank -a 84contigpath.txt -b elementFinder/benchmarks3.insert.bed -o elementFinder/ -x 42insert

cat elementFinder/*insert.stats > elementFinder/42insert.insert.stats

starfish summarize -a 84contigpath.txt -b elementFinder/42insert.flank.bed -x 42insert -o elementFinder/ -S elementFinder/42insert.insert.stats -f elementFinder/42insert.flank.singleDR.stats -t geneFinder/42inserts.filt.ids
